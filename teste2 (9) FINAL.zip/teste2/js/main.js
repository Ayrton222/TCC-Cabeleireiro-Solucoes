$('.slider-principal').slick({
    dots: true,
    infinite: false,
    speed: 300,
    slidesToShow: 1,
    autoplay: true,
    autoplaySpeed: 2000
});